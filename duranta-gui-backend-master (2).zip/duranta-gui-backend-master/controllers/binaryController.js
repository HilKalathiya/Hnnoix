const processManager = require("../services/processManager");

exports.startgnb = async (req, res) => {
  try {
    const result = await processManager.startGNB();

    return res.status(200).json({
      success: true,
      message: result.message,
      status: result.status,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};

exports.stopgnb = async (req, res) => {
  try {
    const result = await processManager.stopGNB();

    return res.status(200).json({
      success: true,
      message: result.message,
      status: result.status,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};

exports.statusgnb = (req, res) => {
  try {
    const status = processManager.getGNBStatus();

    return res.status(200).json({
      success: true,
      status,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};

exports.startue = async (req, res) => {
  try {
    const result = await processManager.startUE();

    return res.status(200).json({
      success: true,
      message: result.message,
      status: result.status,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};

exports.stopue = async (req, res) => {
  try {
    const result = await processManager.stopUE();

    return res.status(200).json({
      success: true,
      message: result.message,
      status: result.status,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};

exports.statusue = (req, res) => {
  try {
    const status = processManager.getUEStatus();

    return res.status(200).json({
      success: true,
      status,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};