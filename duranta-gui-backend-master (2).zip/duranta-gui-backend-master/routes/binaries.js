const express = require('express');
const {exec, spwan} = require('child_process');
const { 
  startgnb, stopgnb, statusgnb, 
  startue, stopue, statusue } = require('../controllers/binaryController');

const binaryRouter = express.Router();

binaryRouter.get('/gnb/start', startgnb)
binaryRouter.get('/gnb/stop', stopgnb)
binaryRouter.get('/gnb/status', statusgnb)


binaryRouter.get('/ue/start', startue)
binaryRouter.get('/ue/stop', stopue)
binaryRouter.get('/ue/status', statusue)

module.exports = binaryRouter